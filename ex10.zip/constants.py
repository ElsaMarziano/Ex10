SNAKE_SIZE = 3
MOVES = {"Up": (0, 1), "Down": (0, -1), "Right": (1, 0), "Left": (-1,0)}
COLORS = {"W": "blue", "S": "black", "A": "green"}
WALL_LENGTH = 3